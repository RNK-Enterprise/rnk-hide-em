# RNK Hide 'Em — Release Notes

## 2.0.8 — 2026-01-30

### Changes
- Restructured language support for a new business model.